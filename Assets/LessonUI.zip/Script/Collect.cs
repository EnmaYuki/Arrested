﻿using UnityEngine;
using System.Collections;

public class Collect : MonoBehaviour {
	
	public AudioClip CoinSound;

	AudioSource AS;

	void Start () {
		AS = GetComponent<AudioSource>();
	}
	
	void OnTriggerEnter (Collider col) {
		if (col.CompareTag("Coin")) {
			CoinCount.UpdateCoin(1);
			AS.PlayOneShot(CoinSound);
			Destroy(col.gameObject);
		}
	}
}
